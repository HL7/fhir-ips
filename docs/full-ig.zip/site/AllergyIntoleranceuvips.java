package http://hl7.org/fhir/ips/ImplementationGuide/ig-uv-ips;

import org.hl7.fhir.r4.model.ProfilingWrapper;

public class AllergyIntoleranceuvips {

}
